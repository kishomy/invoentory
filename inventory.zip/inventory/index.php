<?php require_once 'admin/db_con.php'; ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <title>Hello, world!</title>
  </head>
  <body>
    <div class="container"><br>
      <a class="btn btn-primary float-right" href="admin/login.php">Login</a>
          <h1 class="text-center">Welcome to Inventory Management System!</h1><br>

         
             <hr>
            <h3>New Items</h3>
<table class="table  table-striped table-hover table-bordered" id="data">
  <thead class="thead-dark">
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Item Name</th>
      <th scope="col">Item Category</th>
      <th scope="col">Item Subcategory</th>
      <th scope="col">Item Quantity</th>
    </tr>
  </thead>
  <tbody>
      <?php 
      $query=mysqli_query($db_con,'SELECT * FROM `item` as i JOIN item_category as itc JOIN item_subcategory as itsc on itc.`id`=i.`item_category` and itsc.`id`=i.`item_subcategory` ;');
      $i=1;
      while ($result = mysqli_fetch_array($query)) { ?>
      <tr>
        <?php 
        echo '<td>'.$i.'</td>
          <td>'.ucwords($result['item_name']).'</td>
          <td>'.$result['category'].'</td>
          <td>'.$result['sub_category'].'</td>
          
          <td>'.$result['quantity'].'</td>';?>
      </tr>  
     <?php $i++;} ?>
    
  </tbody>
</table>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>