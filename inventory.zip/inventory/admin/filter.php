<?php  
 //filter.php  
 if(isset($_POST["from_date"], $_POST["to_date"]))  
 {  
      $connect = mysqli_connect("localhost", "root", "", "inventory_db");  
      $output = '';  
      $query = "  
           SELECT * SELECT * FROM `invoice` as i JOIN `invoice_master` as im JOIN `item` as itm JOIN `customer` as cs JOIN `item_category` as imc on i.`id`=im.`id` and im.`item_id`=itm.`id` and i.`customer`=cs.`id` and imc.`id`=itm.`item_category` 
           WHERE i.`date` BETWEEN '".$_POST["from_date"]."' AND '".$_POST["to_date"]."'  
      ";  
      $result = mysqli_query($connect, $query);  
      $output .= '  
           <table class="table table-bordered">  
                <tr>  
                     <th scope="col">SL</th>
      <th scope="col">Invoice number</th>
      <th scope="col">Invoiced date</th>
      <th scope="col">Customer name</th>
      <th scope="col">Item name
with Item code</th>
      <th scope="col">Item category</th>
      <th scope="col">Item unit price</th> 
                </tr>  
      ';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>'. $row["invoice_no"] .'</td>  
                          <td>'. $row["date"] .'</td>  
                          <td>'. $row["first_name"] .'</td>  
                          <td>$ '. $row["item_name"] .'</td>  
                          <td>'. $row["category"] .'</td>
                          <td>'. $row["unit_price"] .'</td>  
                     </tr>  
                ';  
           }  
      }  
      else  
      {  
           $output .= '  
                <tr>  
                     <td colspan="5">No Order Found</td>  
                </tr>  
           ';  
      }  
      $output .= '</table>';  
      echo $output;  
 }  
 ?>