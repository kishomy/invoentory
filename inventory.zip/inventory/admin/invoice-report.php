
<!DOCTYPE html>
<html lang = "en">
  <head>
    <link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css"/>
    <link rel = "stylesheet" type = "text/css" href = "css/jquery-ui.css"/>
        <link rel = "stylesheet" type = "text/css" href = "css/jquery-ui.css"/>

<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

    <meta charset = "UTF-8" name = "viewport" content = "width=device-width, initial-scale=1"/>
  </head>
<body>
<h3>Invoice Report</h3>

  <div class = "form-inline">
        <label>Date:</label>
        <input type = "date" class = "form-control" placeholder = "Start"  id = "date1"/>
        <label>To</label>
        <input type = "date" class = "form-control" placeholder = "End"  id = "date2"/>
        <button type = "button" class = "btn btn-primary fa fa-search" id = "btn_search"><span class = "glyphicon glyphicon-search"></span></button> <button type = "button" id = "reset" class = "btn btn-success fa fa-refresh"><i class="fas fa-sync-alt"></i><span class = "glyphicon glyphicon-refresh"><span></button>
      </div><br>  




 

    
      <div class = "form-inline">
      
      <br /><br />
    
        <table class="table  table-striped table-hover table-bordered" id="data">
  <thead class="thead-dark">
            <tr>
              <th scope="col">SL</th>
              <th scope="col">Invoice Number</th>
              <th scope="col">Date</th>
              <th scope="col">Customer</th>
              <th scope="col">Customer District</th>
               <th scope="col">Item Count</th>
                <th scope="col">Invoice Amount</th>
            </tr>
          </thead>
          <tbody id = "load_data">
            <?php
              $conn = new mysqli("localhost", "root", "", "inventory_db");
              if(!$conn){
                die("Fatal Error: Connection Error!");
              }
              
              $q_book = $conn->query("SELECT * FROM `invoice` as i  JOIN `customer` as cs  JOIN district as ds on i.`customer`=cs.`id` and cs.`district`=ds.`id`") or die(mysqli_error());
                $i=1;
              while($f_book = $q_book->fetch_array()){
            ?>
            <tr>
               <td><?php echo $i?></td>
              <td><?php echo $f_book['invoice_no']?></td>
              <td><?php echo $f_book['date']?></td>
                <td><?php echo $f_book['first_name']?></td>
                <td><?php echo $f_book['district']?></td>
                 <td><?php echo $f_book['item_count']?></td>
                  <td><?php echo $f_book['amount']?></td>
              
            </tr> <?php $i++;} ?>
           
          </tbody>
        </table>
      </div>  
    </div>
  </div>
</body>
<script src = "js/jquery-3.1.1.js"></script>
<script src = "js/jquery-ui.js"></script>
<script src = "js/ajax.js"></script>
</html>