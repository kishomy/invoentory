
<?php  
 
 ?> 
<!DOCTYPE html>
<html lang = "en">
  <head>
    <link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css"/>
    <link rel = "stylesheet" type = "text/css" href = "css/jquery-ui.css"/>
        <link rel = "stylesheet" type = "text/css" href = "css/jquery-ui.css"/>

<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>

    <meta charset = "UTF-8" name = "viewport" content = "width=device-width, initial-scale=1"/>
  </head>
<body>
<h3>Invoice Item Report</h3>
 <form class="form-inline" method="POST" action="">
      <label>Date:</label>
      <input type="date" class="form-control" placeholder="Start"  name="date1" value="<?php echo isset($_POST['date1']) ? $_POST['date1'] : '' ?>" />
      <label>To</label>
      <input type="date" class="form-control" placeholder="End"  name="date2" value="<?php echo isset($_POST['date2']) ? $_POST['date2'] : '' ?>"/>
      <button type = "button" class = "btn btn-primary fa fa-search" id = "btn_search"><span class = "glyphicon glyphicon-search"></span></button> <button type = "button" id = "reset" class = "btn btn-success fa fa-refresh"><i class="fas fa-sync-alt"></i><span class = "glyphicon glyphicon-refresh"><span></button>
  
      <div class = "form-inline">
      
      <br /><br />
<br /><br />
<br /><br />
<br /><br />

<table class="table  table-striped table-hover table-bordered" id="data">
  <thead class="thead-dark">
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Invoice number</th>
      <th scope="col">Invoiced date</th>
      <th scope="col">Customer name</th>
      <th scope="col">Item name
with Item code</th>
      <th scope="col">Item category</th>
      <th scope="col">Item unit price</th>
    </tr>
  </thead>

 <tbody id = "load_data">
            <?php
              $conn = new mysqli("localhost", "root", "", "inventory_db");
              if(!$conn){
                die("Fatal Error: Connection Error!");
              }
              
              $q_book = $conn->query("SELECT * FROM `invoice` as i JOIN `invoice_master` as im JOIN `item` as itm JOIN `customer` as cs JOIN `item_category` as imc on i.`id`=im.`id` and im.`item_id`=itm.`id` and i.`customer`=cs.`id` and imc.`id`=itm.`item_category`") or die(mysqli_error());
                $i=1;
              while($f_book = $q_book->fetch_array()){
            ?>
            <tr>
               <td><?php echo $i?></td>
              <td><?php echo $f_book['invoice_no']?></td>
              <td><?php echo $f_book['date']?></td>
                <td><?php echo $f_book['first_name']?></td>
                <td><?php echo $f_book['item_name']?></td>
                 <td><?php echo $f_book['category']?></td>
                  <td><?php echo $f_book['unit_price']?></td>
              
            </tr> <?php $i++;} ?>
           
          </tbody>
        </table>
      </div>  
    </div>
  </div>
<script src = "js/jquery-3.1.1.js"></script>
<script src = "js/jquery-ui.js"></script>
<script src = "js/ajaxx.js"></script>
