<?php
$Start = date("Y-m-d", strtotime($_POST['Start']));
$End = date("Y-m-d", strtotime($_POST['End']));
$conn = new mysqli("localhost", "root", "", "inventory_db");
if(!$conn){
	die("Fatal Error: Connection Error!");
}
	
$q_book = $conn->query("SELECT * FROM `invoice` as i JOIN `invoice_master` as im JOIN `item` as itm JOIN `customer` as cs JOIN `item_category` as imc on i.`id`=im.`id` and im.`item_id`=itm.`id` and i.`customer`=cs.`id` and imc.`id`=itm.`item_category`; WHERE i.`date` BETWEEN '$Start' AND '$End'") or die(mysqli_error());
$v_book = $q_book->num_rows;
if($v_book > 0){
	while($f_book = $q_book->fetch_array()){
	?>
	<tr>
		<td> <td><?php echo $i?></td>
              <td><?php echo $f_book['invoice_no']?></td>
              <td><?php echo $f_book['date']?></td>
                <td><?php echo $f_book['first_name']?></td>
                <td><?php echo $f_book['item_name']?></td>
                 <td><?php echo $f_book['category']?></td>
                  <td><?php echo $f_book['unit_price']?></td>
              

	</tr><?php $i++;} ?>
	<?php
	}
}else{
		echo '
		<tr>
			<td colspan = "4"><center>Record Not Found</center></td>
		</tr>
		';
}
	?>