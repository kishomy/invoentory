<?php
$date1 = date("Y-m-d", strtotime($_POST['date1']));
$date2 = date("Y-m-d", strtotime($_POST['date2']));
$conn = new mysqli("localhost", "root", "", "inventory_db");
if(!$conn){
	die("Fatal Error: Connection Error!");
}
	
$q_book = $conn->query("SELECT * FROM `invoice` as i  JOIN `customer` as cs  JOIN district as ds on i.`customer`=cs.`id` and cs.`district`=ds.`id` WHERE i.`date` BETWEEN '$date1' AND '$date2'") or die(mysqli_error());
$v_book = $q_book->num_rows;
if($v_book > 0){
	while($f_book = $q_book->fetch_array()){
	?>
	<tr>
		<td><?php echo $f_book['invoice_no']?></td>
              <td><?php echo $f_book['date']?></td>
                <td><?php echo $f_book['first_name']?></td>
                <td><?php echo $f_book['district']?></td>
                 <td><?php echo $f_book['item_count']?></td>
                  <td><?php echo $f_book['amount']?></td>
              

	</tr>
	<?php
	}
}else{
		echo '
		<tr>
			<td colspan = "4"><center>Record Not Found</center></td>
		</tr>
		';
}
	?>