<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
    $corepage = end($corepage);
    if ($corepage!=='index.php') {
      if ($corepage==$corepage) {
        $corepage = explode('.', $corepage);
       header('Location: index.php?page='.$corepage[0]);
     }
    }

  if (isset($_POST['addcustomer'])) {
  	$title = $_POST['title'];
  	$fname = $_POST['fname'];
  	$mname = $_POST['mname'];
  	$lname = $_POST['lname'];
  	$contactno = $_POST['contactno'];
	$district = $_POST['district'];

  	$query = "INSERT INTO `customer`(`title`, `first_name`, `middle_name`, `last_name`, `contact_no`, `district`) VALUES ('$title', '$fname', '$mname', '$lname', '$contactno','$district');";
  	if (mysqli_query($db_con,$query)) {
  		$datainsert['insertsucess'] = '<p style="color: green;">Customer Inserted!</p>';
  		
  	}else{
  		$datainsert['inserterror']= '<p style="color: red;">Customer Not Inserted, please input right informations!</p>';
  	}
  }
?>


	<script type="text/javascript">

		function validation(){

	var number=document.getElementById("contactno").value;///get id with value 

	var numberpattern=/^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;////Regular expression

	if(numberpattern.test(number))

	   {

		document.getElementById("contactno").style.borderColor='green';

       }

    else

      {

    	document.getElementById("contactno").style.borderColor='red'; 

      }

	}

	</script>
<h1 class="text-primary"><i class="fas fa-user-plus"></i>  Add Customer<small class="text-warning"> Add New Customer!</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="index.php">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Add Customer</li>
  </ol>
</nav>

<div class="row">
	
<div class="col-sm-6">
		<?php if (isset($datainsert)) {?>
	<div role="alert" aria-live="assertive" aria-atomic="true" class="toast fade" data-autohide="true" data-animation="true" data-delay="2000">
	  <div class="toast-header">
	    <strong class="mr-auto">Customer Insert Alert</strong>
	    <small><?php echo date('d-M-Y'); ?></small>
	    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
	      <span aria-hidden="true">&times;</span>
	    </button>
	  </div>
	  <div class="toast-body">
	    <?php 
	    	if (isset($datainsert['insertsucess'])) {
	    		echo $datainsert['insertsucess'];
	    	}
	    	if (isset($datainsert['inserterror'])) {
	    		echo $datainsert['inserterror'];
	    	}
	    ?>
	  </div>
	</div>
		<?php } ?>
	<form enctype="multipart/form-data" method="POST" action="">
		<div class="form-group">
		    <label for="title">Title</label>
		    <input name="title" type="text" class="form-control" id="title" value="<?= isset($title)? $title: '' ; ?>" required="">
	  	</div>
		<div class="form-group">
		    <label for="fname">First Name</label>
		    <input name="fname" type="text" class="form-control" id="fname" value="<?= isset($fname)? $fname: '' ; ?>" required="">
	  	</div>
		<div class="form-group">
		    <label for="mname">Middle Name</label>
		    <input name="mname" type="text" class="form-control" id="mname" value="<?= isset($mname)? $mname: '' ; ?>" >
	  	</div>
	  	<div class="form-group">
		    <label for="lname">Last Name</label>
		    <input name="lname" type="text" class="form-control" id="lname" value="<?= isset($lname)? $lname: '' ; ?>" required="">
	  	</div>
	  	
	  	<div class="form-group">
		    <label for="contactno">Contact NO</label>
		    <input name="contactno" type="text" class="form-control" id="contactno"  value="<?= isset($contactno)? $contactno: '' ; ?>"  required="" maxlength="10" minlength="10" onkeyup="validation()">
	  	</div>
	  	
	  		<div class="form-group">
		    <label for="district">District</label>
	<select  name="district" id="district" class="form-control" required="">

    						<option disabled selected>-- Please Select the District --</option>

        							<?php
        							  $con = mysqli_connect("localhost","root","","inventory_db");
        							 $query =mysqli_query($con,"SELECT * FROM district");

										while($row=mysqli_fetch_array($query))

											{ ?>

							<option value="<?php echo $row['id'];?>"><?php echo $row['district'];?></option>

									<?php

										}

									?>

 						</select>
			</div>
	  	<div class="form-group text-center">
		    <input name="addcustomer" value="Add Customer" type="submit" class="btn btn-danger">
	  	</div>
	 </form>
</div>
</div>