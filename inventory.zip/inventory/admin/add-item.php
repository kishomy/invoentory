<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
    $corepage = end($corepage);
    if ($corepage!=='index.php') {
      if ($corepage==$corepage) {
        $corepage = explode('.', $corepage);
       header('Location: index.php?page='.$corepage[0]);
     }
    }

  if (isset($_POST['additem'])) {
  	$code = $_POST['code'];
  	$iname = $_POST['iname'];
  	$category = $_POST['category'];
  	$subcategory = $_POST['subcategory'];
  	$quantity = $_POST['quantity'];
	$uprice = $_POST['uprice'];

  	$query = "INSERT INTO `item`(`item_code`, `item_category`, `item_subcategory`, `item_name`, `quantity`, `unit_price`) VALUES ('$code', '$category', '$subcategory', '$iname', '$quantity','$uprice');";
  	if (mysqli_query($db_con,$query)) {
  		$datainsert['insertsucess'] = '<p style="color: green;">Item Inserted!</p>';
  		
  	}else{
  		$datainsert['inserterror']= '<p style="color: red;">Item Not Inserted, please input right informations!</p>';
  	}
  }
  
?>
<<!DOCTYPE html>
<html>
<head>


	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>

</head>
<body>


	

<h1 class="text-primary"><i class="fas fa-plus"></i>  Add Item<small class="text-warning"> Add New Item!</small></h1>
<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
     <li class="breadcrumb-item" aria-current="page"><a href="index.php">Dashboard </a></li>
     <li class="breadcrumb-item active" aria-current="page">Add Item</li>
  </ol>
</nav>

<div class="row">
	
<div class="col-sm-6">
		<?php if (isset($datainsert)) {?>
	<div role="alert" aria-live="assertive" aria-atomic="true" class="toast fade" data-autohide="true" data-animation="true" data-delay="2000">
	  <div class="toast-header">
	    <strong class="mr-auto">Item Insert Alert</strong>
	    <small><?php echo date('d-M-Y'); ?></small>
	    <button type="button" class="ml-2 mb-1 close" data-dismiss="toast" aria-label="Close">
	      <span aria-hidden="true">&times;</span>
	    </button>
	  </div>
	  <div class="toast-body">
	    <?php 
	    	if (isset($datainsert['insertsucess'])) {
	    		echo $datainsert['insertsucess'];
	    	}
	    	if (isset($datainsert['inserterror'])) {
	    		echo $datainsert['inserterror'];
	    	}
	    ?>
	  </div>
	</div>
		<?php } ?>
	<form enctype="multipart/form-data" method="POST" action="">
		<div class="form-group">
		    <label for="code">Item Code</label>
		    <input name="code" type="text" class="form-control" id="code" value="<?= isset($code)? $code: '' ; ?>" required="">
	  	</div>
		<div class="form-group">
		    <label for="iname">Item Name</label>
		    <input name="iname" type="text" class="form-control" id="iname" value="<?= isset($iname)? $iname: '' ; ?>" required="">
	  	</div>
		<div class="form-group">
		    <label for="mname">Item Category</label>
	<select  name="category" id="category" class="form-control" required="">

    						<option disabled selected>-- Please Select the Category --</option>

        							<?php
        							  $con = mysqli_connect("localhost","root","","inventory_db");
        							 $query =mysqli_query($con,"SELECT * FROM item_category");

										while($row=mysqli_fetch_array($query))

											{ ?>

							<option value="<?php echo $row['id'];?>"><?php echo $row['category'];?></option>

									<?php

										}

									?>

 						</select>
			</div>
	  	<div class="form-group">
		    <label for="subcategory">Item Subcategory</label>
		   <select  name="subcategory" id="subcategory" class="form-control" required="">

    						<option disabled selected>-- Please Select the Subcategory --</option>

        							<?php
        							  $con = mysqli_connect("localhost","root","","inventory_db");
        							 $query =mysqli_query($con,"SELECT * FROM item_subcategory");

										while($row=mysqli_fetch_array($query))

											{ ?>

							<option value="<?php echo $row['id'];?>"><?php echo $row['sub_category'];?></option>

									<?php

										}

									?>

 						</select>
	  	</div>
	  	
	  	<div class="form-group">
		    <label for="quantity">Quantity</label>
		    <input name="quantity" type="text" class="form-control" id="quantity"  value="<?= isset($quantity)? $quantity: '' ; ?>"  required="">
	  	</div>
	  	<div class="form-group">
		    <label for="uprice">Unit Price</label>
		    <input name="uprice" type="text" class="form-control" id="uprice" value="<?= isset($uprice)? $uprice: '' ; ?>" required="">
	  	</div>
	  	
	  	<div class="form-group text-center">
		    <input name="additem" value="Add Item" type="submit" class="btn btn-danger">
	  	</div>
	 </form>
</div>
</div>

</body>
</html>