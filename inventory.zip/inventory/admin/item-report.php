<?php 
  $corepage = explode('/', $_SERVER['PHP_SELF']);
    $corepage = end($corepage);
    if ($corepage!=='index.php') {
      if ($corepage==$corepage) {
        $corepage = explode('.', $corepage);
       header('Location: index.php?page='.$corepage[0]);
     }
    }
    ?>
<h3>Item Report</h3>
<table class="table  table-striped table-hover table-bordered" id="data">
  <thead class="thead-dark">
    <tr>
      <th scope="col">SL</th>
      <th scope="col">Item Name</th>
      <th scope="col">Item Category</th>
      <th scope="col">Item Subcategory</th>
      <th scope="col">Item Quantity</th>
    </tr>
  </thead>
  <tbody>
    <?php 
      $query=mysqli_query($db_con,'SELECT * FROM `item` as i JOIN item_category as itc JOIN item_subcategory as itsc on itc.`id`=i.`item_category` and itsc.`id`=i.`item_subcategory` ;');
      $i=1;
      while ($result = mysqli_fetch_array($query)) { ?>
      <tr>
        <?php 
        echo '<td>'.$i.'</td>
          <td>'.ucwords($result['item_name']).'</td>
          <td>'.$result['category'].'</td>
          <td>'.$result['sub_category'].'</td>
          
          <td>'.$result['quantity'].'</td>';?>
      </tr>  
     <?php $i++;} ?>
    
  </tbody>
</table>