-------------------MySQL Database Server--------------

Database Name : inventory_db

---------------Default Admin username & password------

username : admin
password : Admin@123